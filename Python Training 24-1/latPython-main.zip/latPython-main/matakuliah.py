list = { 
        1 : {'nama':'Big Data', 'sks':2},
        2 : {'nama':'Kecerdasa Buatan', 'sks':2},
        3 : {'nama':'Algoritma Komputasi', 'sks':2}
    }
